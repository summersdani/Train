﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewEngines;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Mvc;
using Train.Models;

namespace Train.Manager
{
    public class TrainManager
    {
        public List<TrainDetails> GetTrainData()
        {
            List<TrainDetails> Trains = new List<TrainDetails>();

            var filePath = "TrainData/TrainData.txt";
            string[] trainData = File.ReadAllLines(filePath);

            if (trainData != null && trainData.Length > 0)
            {
                foreach (var line in trainData)
                {
                    var t = line.Split(',');
                    string departure = t[0];
                    string destination = t[1];
                    int seats = !string.IsNullOrEmpty(t[2]) ? int.Parse(t[2]) : 0;

                    TrainDetails train = new TrainDetails(departure, destination, seats);
                    Trains.Add(train);
                }
            }

            return Trains;
        }

    }
}
