using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewEngines;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Train.Manager;
using Train.Models;

namespace Train.Controllers
{
    public class HomeController(ICompositeViewEngine viewEngine) : Controller
    {
        private readonly ICompositeViewEngine _viewEngine = viewEngine ?? throw new ArgumentNullException(nameof(viewEngine));

        public ActionResult Index()
        {
            var model = new TrainViewModel();
            var mgr = new TrainManager();
            model.AllTrainDetails = mgr.GetTrainData();

            return View("Index", model);
        }

        public JsonResult GetTrainBooking(string departureTime, string destination, int seats)
        {
            var model = new TrainViewModel();
            var mgr = new TrainManager();
            model.TrainDetails = new TrainDetails(departureTime, destination, seats);
            string partialViewHtml = RenderPartialViewToString("_GetTrainBooking", model);

            return Json(new { PartialViewHtml = partialViewHtml });

        }

        public JsonResult BookTrain(string destination, string selectedSeat, int allSeats)
        {
            string message;
            bool modal = true;

            if (allSeats <= 0)
            {
                message = $"No available seats to {destination}. Please select a different train.";
            }
            else if (string.IsNullOrEmpty(selectedSeat))
            {
                modal = false;
                message = "Please select your seats before submitting.";
            }
            else
            {
                var halfOfSeats = (double)allSeats / 2;
                var windowSeat = Math.Ceiling(halfOfSeats);
                var aisleSeat = allSeats - windowSeat;

                if ((selectedSeat == "window" && windowSeat > 0) || (selectedSeat == "aisle" && aisleSeat > 0))
                {
                    message = $"You successfully booked your {selectedSeat} seat to {destination}.";
                }
                else
                {
                    modal = windowSeat <= 0 || aisleSeat <= 0;
                    message = $"No {selectedSeat} seats are available. Please select a different seat.";
                }
            }

            return Json(new { Message = message, HideModal = modal });
        }

        private string RenderPartialViewToString(string viewName, object model)
        {
            ViewData.Model = model;

            using (var sw = new StringWriter())
            {
                var viewResult = _viewEngine.FindView(ControllerContext, viewName, false);

                if (viewResult.View == null)
                {
                    throw new ArgumentNullException($"{viewName} is not available");
                }

                var viewContext = new ViewContext(ControllerContext, viewResult.View, ViewData, TempData, sw, new HtmlHelperOptions());

                viewResult.View.RenderAsync(viewContext).GetAwaiter().GetResult();
                return sw.GetStringBuilder().ToString();
            }
        }

    }
}
