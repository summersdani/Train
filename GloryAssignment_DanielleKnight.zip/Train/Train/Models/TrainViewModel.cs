﻿namespace Train.Models
{
    public class TrainViewModel
    {
        public TrainViewModel()
        {
            AllTrainDetails = new List<TrainDetails>();
            TrainDetails = new TrainDetails("", "", 0);
        }
        public List<TrainDetails> AllTrainDetails { get; set; }
        public TrainDetails TrainDetails { get; set; }
    }

    public class TrainDetails
    {
        public TrainDetails(string departure, string destination, int seats)
        {
            DepartureTime = departure;
            Destination = destination;
            AvailableSeats = seats;
        }

        public string DepartureTime { get; set; }
        public string Destination { get; set; }
        public int AvailableSeats { get; set; }
    }
}
