﻿// Please see documentation at https://learn.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
(function () {

    $(".book-train-btn").on("click", function () {
        var time = $(this).attr('data-time'); 
        var destination = $(this).attr('data-destination'); 
        var seats = $(this).attr('data-seats');

        $.ajax({
            url: "Home/GetTrainBooking",
            method: "GET",
            data: { departureTime: time, destination: destination, seats: seats },
            dataType: "json",
            success: function (response) {
                $("#bookTrainContainer").removeClass("hidden");
                $("#bookTrainContainer").html(response.partialViewHtml);
            },
            error: function (xhr, status, error) {
                console.error("Error:", error);
            }
        });
    });

    // Save booking
    $("#bookTrainContainer").on("click", "#saveBookingBtn", function () {
        var selectedSeat = $("input[type='radio']:checked").val();
        var destination = $("#destination").val();
        var seats = $("#allSeats").val();
        $.ajax({
            url: "Home/BookTrain",
            method: "GET",
            data: { destination: destination, selectedSeat: selectedSeat, allSeats: seats },
            dataType: "json",
            success: function (response) {
                console.log(response);
                if (response.hideModal == true) {
                    $("#mainMessage").html(response.message);   
                    $("#bookTrainContainer").html("");
                    $("#bookTrainContainer").addClass("hidden");
                }
                else {
                    $("#errorModalMessage").html(response.message);
                }
            },
            error: function (xhr, status, error) {
                console.error("Error:", error);
            }
        });

        
    });

    // Cancel modal pop up
    $("#bookTrainContainer").on("click", "#cancelBookingBtn", function () {
        $("#bookTrainContainer").html("");
        $("#bookTrainContainer").addClass("hidden");
    });

})();